@extends('layouts.app')

@section('content')
   <shopping-cart></shopping-cart>
@endsection

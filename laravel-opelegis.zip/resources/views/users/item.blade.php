@extends('layouts.app')

@section('content')
  <h1>{{$user->name}}</h1>
  {!! $user->curriculo !!}
@endsection

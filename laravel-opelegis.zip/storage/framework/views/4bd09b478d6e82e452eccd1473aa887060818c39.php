

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <p>
            <h3><i class="fa fa-flag" aria-hidden="true"></i> <strong><?php echo e($page->title); ?></strong></h3></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo $page->body; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
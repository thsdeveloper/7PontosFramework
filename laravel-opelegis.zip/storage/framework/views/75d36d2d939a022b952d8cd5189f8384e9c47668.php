

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <p>
            <h3><i class="fa fa-flag" aria-hidden="true"></i> <strong>Produtos relacionados</strong></h3></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php $__empty_1 = true; $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <div class="box-product">
                        <div class="img-wrapper">
                            <a href="<?php echo e(url('produto/'.$produto->slug)); ?>">

                                <img src="<?php echo e(Voyager::image($produto->image)); ?>" alt="Categoria NetCriativa sem Imagem"
                                     class="img-responsive">

                            </a>
                            <div class="tags tags-left">
                                <span class="label-tags"><span
                                            class="label label-success arrowed-right">Frete Grátis - <?php echo e($produto->code); ?></span></span>
                            </div>
                        </div>
                        <h6><a href="#"><?php echo e($produto->name); ?></a></h6>
                        <div class="mold_info_product">
                            <span class="labelcartao"><b>3x</b> no cartão de crédito</span>
                            <br>
                            <span class="labeltag"><b>5%</b> de desconto no boleto à vista</span>
                        </div>
                        <br>
                        <a href="#" class="btn btn-primary center-block">Detalhes | preço</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="caixa-destaque">
                    <h1>Não existem produtos nessa categoria</h1>
                    <p>
                        Você está tentando acessar uma categoria, mas não existem produtos adicionados nela.
                    </p>
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Ir às compras</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="mold-banner">
        <?php echo $__env->make('banners.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <p>
            <h3><i class="fa fa-flag" aria-hidden="true"></i> <strong>Lançamentos / Destaques</strong></h3></p>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="box-product">
                    <div class="img-wrapper">
                        <a href="<?php echo e(url('produto/'.$pro->slug)); ?>">
                            <img src="<?php echo e(Voyager::image($pro->image)); ?>" alt="Categoria NetCriativa sem Imagem"
                                 class="img-responsive">
                        </a>
                    </div>
                    <h6><a href="#"><?php echo e($pro->name); ?></a></h6>
                    <div class="mold_info_product">
                        <span class="labelcartao"><b>3x</b> no cartão de crédito</span>
                        <br>
                        <span class="labeltag"><b>5%</b> de desconto no boleto à vista</span>
                    </div>
                    <a href="<?php echo e(url('produto/'.$pro->slug)); ?>" class="btn btn-primary center-block">Detalhes | preço</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>